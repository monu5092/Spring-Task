package com.cn.cnkart.dal;

public interface ItemDetailsDAL {

    void delete(int id);
}
