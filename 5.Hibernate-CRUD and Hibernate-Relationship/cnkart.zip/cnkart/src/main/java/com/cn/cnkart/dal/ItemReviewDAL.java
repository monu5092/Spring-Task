package com.cn.cnkart.dal;

import com.cn.cnkart.entity.ItemReview;

public interface ItemReviewDAL {

    void save(ItemReview review);

}
